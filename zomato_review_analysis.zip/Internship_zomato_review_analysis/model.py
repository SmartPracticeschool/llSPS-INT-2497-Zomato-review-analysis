#text-preprocessing
#importing the data set
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
df=pd.read_csv('Restaurant_Reviews.tsv', encoding = "ISO-8859-1",nrows=10000,delimiter="\t",quoting=3)
import re#library used to remove punctuation
import nltk#library used for stemming
nltk.download('stopwords')#downloading stopwords
from nltk.corpus import stopwords#importing library for stopwords
from nltk.stem.porter import PorterStemmer#importing library for stemming
data=[]
for i in range(0,1000):
        review=df['Review'][i]
        review = re.sub('[^a-zA-Z]', ' ', review)#removing punctuation,numbers
        review = review.lower()#converting words into lower case
        review = review.split()
        ps = PorterStemmer()
        review = [ps.stem(word) for word in review if not word in set(stopwords.words('english'))]
        review = ' '.join(review)
        data.append(review)
#splitting model into training and test set
from sklearn.feature_extraction.text import CountVectorizer
cv = CountVectorizer(max_features=1500)
X = cv.fit_transform(data).toarray()
y=df.iloc[:,1].values
import pickle
pickle.dump(cv, open("cv.pkl", "wb"))
#model buiding
#importing model building libraries
from keras.models import Sequential
from keras.layers import Dense
model = Sequential()#initializing the model
model.add(Dense(output_dim = 64, init = 'uniform', activation = 'relu', input_dim = X.shape[1]))#adding input layer
model.add(Dense(output_dim = 16, init = 'uniform', activation = 'relu'))#adding hidden layer
model.add(Dense(output_dim = 1, init = 'uniform', activation = 'sigmoid'))#adding output layer
model.compile(optimizer = 'adam', loss = 'binary_crossentropy', metrics = ['accuracy'])#configure the model
#training the model
X_train=X
y_train=y
model.fit(X_train,y_train,batch_size=128,epochs=5000)
#optimize the model
from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred)

from sklearn.metrics import accuracy_score
accuracy_score(y_test, y_pred)
#save the model
model.save('model.h5')

    
