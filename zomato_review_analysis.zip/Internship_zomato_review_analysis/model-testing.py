from keras.models import load_model
import pickle
model=load_model('model.h5')
with open('cv.pkl','rb') as file:
        cv=pickle.load(file)    
        model=load_model('model.h5')
        da=input()
        da=da.split("delimiter")
        prediction = model.predict(cv.transform(da))
        result=prediction[0]
        if result>0.5:
            print("it is positive review")
        elif result==0.5:
            print("it is neutral review")
        else:
            print("it is negative review")
